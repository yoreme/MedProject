--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE medprojdb;
--
-- Name: medprojdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE medprojdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Nigeria.1252' LC_CTYPE = 'English_Nigeria.1252';


ALTER DATABASE medprojdb OWNER TO postgres;

\connect medprojdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: lookups_second_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lookups_second_category (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    name character varying(50) NOT NULL,
    firstcategory_id integer
);


ALTER TABLE public.lookups_second_category OWNER TO postgres;

--
-- Name: lookups_second_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lookups_second_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lookups_second_category_id_seq OWNER TO postgres;

--
-- Name: lookups_second_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lookups_second_category_id_seq OWNED BY public.lookups_second_category.id;


--
-- Name: lookups_second_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lookups_second_category ALTER COLUMN id SET DEFAULT nextval('public.lookups_second_category_id_seq'::regclass);


--
-- Data for Name: lookups_second_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lookups_second_category (id, created_at, updated_at, is_deleted, name, firstcategory_id) FROM stdin;
\.
COPY public.lookups_second_category (id, created_at, updated_at, is_deleted, name, firstcategory_id) FROM '$$PATH$$/2895.dat';

--
-- Name: lookups_second_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lookups_second_category_id_seq', 68, true);


--
-- Name: lookups_second_category lookups_second_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lookups_second_category
    ADD CONSTRAINT lookups_second_category_pkey PRIMARY KEY (id);


--
-- Name: lookups_second_category_firstcategory_id_dfc2e05d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lookups_second_category_firstcategory_id_dfc2e05d ON public.lookups_second_category USING btree (firstcategory_id);


--
-- Name: lookups_second_category lookups_second_categ_firstcategory_id_dfc2e05d_fk_lookups_f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lookups_second_category
    ADD CONSTRAINT lookups_second_categ_firstcategory_id_dfc2e05d_fk_lookups_f FOREIGN KEY (firstcategory_id) REFERENCES public.lookups_first_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

